// Copyright (c) 2022, the R8 project authors. Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

package com.android.tools.r8;

import com.android.tools.r8.keepanno.annotations.KeepForApi;
import java.io.OutputStream;
import java.nio.charset.Charset;

@KeepForApi
public interface TextOutputStream {

  OutputStream getOutputStream();

  Charset getCharset();
}
